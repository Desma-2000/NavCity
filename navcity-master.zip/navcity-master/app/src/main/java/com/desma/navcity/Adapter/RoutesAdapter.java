package com.desma.navcity.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.desma.navcity.Authentication;
import com.desma.navcity.Model.Route;
import com.desma.navcity.R;
import com.desma.navcity.SpecificRoute;
import com.google.gson.Gson;

import java.util.ArrayList;

public class RoutesAdapter extends RecyclerView.Adapter<RoutesAdapter.ViewHolder> {
    Context context;
    ArrayList<Route> routeArrayList;
    Activity activity;
    SharedPreferences.Editor editor;

    public  RoutesAdapter(Context c,ArrayList<Route> routes,Activity act){
        this.context = c;
        this.routeArrayList = routes;
        this.activity = act;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.route_layout,parent,false);
        return  new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Route route_item = routeArrayList.get(position);
        holder.bindRoutes(routeArrayList.get(position));

        holder.card_route.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getApplicationContext(), SpecificRoute.class);
                editor.putString("Route", String.valueOf(route_item));
                editor.commit();
                intent.putExtra("Route",new Gson().toJson(route_item));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return routeArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout container_card;
        LinearLayout card_route;
        TextView source_destination,sacco,fare;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            editor = context.getSharedPreferences("Route",Context.MODE_PRIVATE).edit();
            container_card = itemView.findViewById(R.id.container_card);
            card_route = itemView.findViewById(R.id.card_route);
            source_destination = itemView.findViewById(R.id.source_destination);
            sacco = itemView.findViewById(R.id.sacco);
            fare = itemView.findViewById(R.id.fare_route);
        }

        public void bindRoutes(Route route) {
            source_destination.setText(route.getSource()+" - "+route.getDestination());
            sacco.setText(route.getSacco());
            fare.setText("Ksh "+String.valueOf(route.getFare()));
        }
    }
}
