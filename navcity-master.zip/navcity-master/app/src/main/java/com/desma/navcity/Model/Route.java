package com.desma.navcity.Model;

public class Route {
    private String source,sacco,destination,description,map_link,date,time; //7
    private int favorites,rating,fare;

    public Route(){}
    public Route(String source, String sacco, String destination, String description, String map_link, String date, String time, int favorites, int rating, int fare) {
        this.source = source;
        this.sacco = sacco;
        this.destination = destination;
        this.description = description;
        this.map_link = map_link;
        this.date = date;
        this.time = time;
        this.favorites = favorites;
        this.rating = rating;
        this.fare = fare;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSacco() {
        return sacco;
    }

    public void setSacco(String sacco) {
        this.sacco = sacco;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMap_link() {
        return map_link;
    }

    public void setMap_link(String map_link) {
        this.map_link = map_link;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getFavorites() {
        return favorites;
    }

    public void setFavorites(int favorites) {
        this.favorites = favorites;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getFare() {
        return fare;
    }

    public void setFare(int fare) {
        this.fare = fare;
    }
}
