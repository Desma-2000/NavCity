package com.desma.navcity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import com.desma.navcity.Model.Route;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;

public class SpecificRoute extends AppCompatActivity {
    SharedPreferences preferences;
    WebView webView;
    String route,link ;
    String url ="https://maps.com";
    TextView description,favourite_count;
    ImageView one_star,two_star,three_star,four_star,five_star;
    Drawable outline_star,filled_star;
    MaterialButton open_maps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific_route);

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                handleSendText(intent); // Handle text being sent
            }
        }
        webView = findViewById(R.id.webview);
        description = findViewById(R.id.description);
        favourite_count  = findViewById(R.id.favourite_count);
        one_star = findViewById(R.id.one_star);
        two_star = findViewById(R.id.two_star);
        four_star = findViewById(R.id.four_star);
        five_star = findViewById(R.id.five_star);
        three_star = findViewById(R.id.three_star);
        outline_star = getResources().getDrawable(R.drawable.ic_baseline_star_outline_24);
        filled_star = getResources().getDrawable(R.drawable.ic_baseline_star_rate_24);
        open_maps = findViewById(R.id.open_maps);


        preferences = getApplicationContext().getSharedPreferences("Route", MODE_PRIVATE);
        route = preferences.getString("Route",null);
        String jsonMyObject = null;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            jsonMyObject = extras.getString("Route");
        }
        Route routeObject = new Gson().fromJson(jsonMyObject, Route.class);

        if(routeObject != null) {
            setTitle(routeObject.getSource() + " - " + routeObject.getDestination());
            favourite_count.setText(String.valueOf(routeObject.getFavorites()));

            description.setText(routeObject.getDescription());

            rate(routeObject.getRating());
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    setUpwebView(webView, routeObject);
                }
            },4000);
            url = routeObject.getMap_link();
            link =routeObject.getMap_link();
        }
        open_maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(intent);
            }
        });
    }
    void handleSendText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null) {
            // Update UI to reflect text being shared
            Log.d("INTENT",sharedText);

        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleSendText(intent);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setUpwebView(WebView webView, Route routeObject) {
        webView.loadUrl(routeObject.getMap_link());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {


                String ur = request.getUrl().toString();
                String[] o = ur.split("=");
                String my_url_ = String.valueOf(o[3]);
                String[] refine = my_url_.split("data");
                String my_url = String.valueOf(refine[0]);

                if(request.getUrl().toString().contains("navlite")) {
                    String[] z = ur.split("link=");
                    my_url = String.valueOf(z[1]);
                }

                Log.d("MAP_URL",my_url);

                // intent://maps.app.goo.gl/5sQPriwWSr6n97kE7#Intent;package=com.google.android.gms;scheme=https;S.browser_fallback_url=https://www.google.com/maps/dir/-1.3894237,36.7673052/Tembo%2BCo%2B-%2BOp%2BHouse%2BBuilding,%2BTembo%2BHouse,%2BMoi%2BAve,%2BNairobi/data%3D!4m10!4m9!1m1!4e1!1m5!1m4!1s0x182f10d453c83fab:0xb2e51ad1cc8d7a3!8m2!3d-1.2819158!4d36.8220788!3e0%3Futm_source%3Dmstt_0;end;

                view.loadUrl(my_url);
                return true;
//                view.loadUrl(request.getUrl().toString());
//                return false;
            }
        });
    }


    private void rate(int rating) {
        if (rating == 1){
            one_star.setImageDrawable(filled_star);
            two_star.setImageDrawable(outline_star);
            three_star.setImageDrawable(outline_star);
            four_star.setImageDrawable(outline_star);
            five_star.setImageDrawable(outline_star);
        }
        else if(rating == 2){
            one_star.setImageDrawable(filled_star);
            two_star.setImageDrawable(filled_star);
            three_star.setImageDrawable(outline_star);
            four_star.setImageDrawable(outline_star);
            five_star.setImageDrawable(outline_star);
        }
        else if(rating == 3){
            one_star.setImageDrawable(filled_star);
            two_star.setImageDrawable(filled_star);
            three_star.setImageDrawable(filled_star);
            four_star.setImageDrawable(outline_star);
            five_star.setImageDrawable(outline_star);
        }
        else if(rating == 4){
            one_star.setImageDrawable(filled_star);
            two_star.setImageDrawable(filled_star);
            three_star.setImageDrawable(filled_star);
            four_star.setImageDrawable(filled_star);
            five_star.setImageDrawable(outline_star);
        }
        else if(rating == 5){
            one_star.setImageDrawable(filled_star);
            two_star.setImageDrawable(filled_star);
            three_star.setImageDrawable(filled_star);
            four_star.setImageDrawable(filled_star);
            five_star.setImageDrawable(filled_star);
        }
    }
}


/*           <intent-filter tools:ignore="AppLinkUrlError">-->
<!--                <action android:name="android.intent.action.VIEW" />-->
<!--                <category android:name="android.intent.category.BROWSABLE" />-->
<!--                <category android:name="android.intent.category.DEFAULT" />-->
<!--                <data android:host="maps.app.goo.gl"-->
<!--                    android:scheme="https" />-->
<!--            </intent-filter>-->
 */