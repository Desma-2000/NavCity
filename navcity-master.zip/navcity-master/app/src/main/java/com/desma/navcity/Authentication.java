package com.desma.navcity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.Pattern;

public class Authentication extends AppCompatActivity implements View.OnClickListener {
MaterialButton loginButton,signUpButton;
TextInputEditText loginEmailInput,loginPasswordInput,signUpEmailInput,signUpPasswordInput,signUpConfirmPasswordInput;
TextInputLayout loginEmailLayout,loginPasswordLayout,signUpEmailLayout,signUpPasswordLayout,signUpConfirmPasswordLayout;
TextView login_redirect,signUpRedirect;
ConstraintLayout signUpSection,loginSection;
    private FirebaseAuth mAuth;
    FirebaseUser currentUser;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser != null){
            move();
        }
        createDialog();

        signUpSection = findViewById(R.id.signUpSection);
        loginSection = findViewById(R.id.loginSection);
        signUpRedirect = findViewById(R.id.signUpRedirect);
        login_redirect = findViewById(R.id.login_redirect);

        login_redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginSection.setVisibility(View.VISIBLE);
                signUpSection.setVisibility(View.GONE);
            }
        });

        signUpRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginSection.setVisibility(View.GONE);
                signUpSection.setVisibility(View.VISIBLE);
            }
        });
//        login
        loginButton = findViewById(R.id.loginButton);
        loginPasswordInput = findViewById(R.id.loginPasswordInput);
        loginEmailInput = findViewById(R.id.loginEmailInput);
        loginEmailLayout = findViewById(R.id.loginEmailLayout);
        loginPasswordLayout = findViewById(R.id.loginPasswordLayout);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = String.valueOf(loginEmailInput.getText());
                String pwd = String.valueOf(loginPasswordInput.getText());

                if(email.trim().length() <= 0){
                    loginEmailLayout.setError("email is required");

                }
                if (!(Patterns.EMAIL_ADDRESS.matcher(email).matches())){
                    loginEmailLayout.setError("Invalid email address");
                }
                if(pwd.trim().length() < 6){
                    loginPasswordLayout.setError("password is too short");
                }

                if(email.trim().length() > 6 && pwd.trim().length() > 0 &&  Patterns.EMAIL_ADDRESS.matcher(email).matches() ) {
                    progressDialog.show();
                    mAuth.signInWithEmailAndPassword(email,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                FirebaseUser user = mAuth.getCurrentUser();
                                if (user!=null){
                                    progressDialog.hide();
                                    move();
                                }
                            }
                            else{
                                progressDialog.hide();
                                showError(String.valueOf(task.getException()),v);
                            }
                        }
                    });
                }
                else{
                    showError("Check on Credentials",v);
                }
            }
        });

        // sign up
        signUpEmailInput = findViewById(R.id.signUpEmailInput);
        signUpPasswordInput = findViewById(R.id.signUpPasswordInput);
        signUpConfirmPasswordInput = findViewById(R.id.signUpConfirmPasswordInput);
        signUpEmailLayout = findViewById(R.id.signUpEmailLayout);
        signUpPasswordLayout = findViewById(R.id.signUpPasswordLayout);
        signUpConfirmPasswordLayout = findViewById(R.id.signUpConfirmPasswordLayout);
        signUpButton = findViewById(R.id.signUpButton);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = String.valueOf(signUpEmailInput.getText());
                String pwd = String.valueOf(signUpPasswordInput.getText());
                String confPwd = String.valueOf(signUpConfirmPasswordInput.getText());


                if(email.trim().length() <= 0){
                    signUpEmailLayout.setError("email is required");

                }
                if (!(Patterns.EMAIL_ADDRESS.matcher(email).matches())){
                    signUpEmailLayout.setError("Invalid email address");
                }
                if(pwd.trim().length() < 6){
                    signUpPasswordLayout.setError("password is too short");
                }
                if(!(confPwd.matches(pwd))){
                    signUpConfirmPasswordLayout.setError("Password mismatch");
                }

                if(confPwd.matches(pwd) && pwd.trim().length() > 6 && Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    progressDialog.show();
                    mAuth.createUserWithEmailAndPassword(email,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                FirebaseUser user = mAuth.getCurrentUser();
                                if (user!=null){
                                    progressDialog.hide();
                                    move();
                                }
                            }
                            else{
                                progressDialog.hide();
                                showError(task.getException().toString(),v);
                            }
                        }
                    });
                }
                else{
                    showError("Check on Credentials",v);
                }
            }
        });
    }

    private void createDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Authentication");
        progressDialog.setMessage("processing..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMax(100);
        progressDialog.setCancelable(false);
    }

    private void showError(String exception, View v) {
        Snackbar.make(v,exception,Snackbar.LENGTH_LONG).show();
    }

    private void move() {
        Intent intent = new Intent(getApplicationContext(),dashboard.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View v) {

    }
}