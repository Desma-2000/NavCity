package com.desma.navcity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.desma.navcity.Model.Route;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.util.Date;

public class RouteUpload extends AppCompatActivity {
TextInputEditText source_location,destination_location,description_route,url_route,sacco_route,fare_route,rating_route;
MaterialButton addRoute;
TextInputLayout source_location_layout,destination_location_layout,description_route_layout,url_route_layout,rating_route_layout,sacco_route_layout,fare_route_layout;
    FirebaseDatabase database ;
    DatabaseReference myRef;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createDialog();
        setContentView(R.layout.activity_route_upload);
        database =  FirebaseDatabase.getInstance();

        source_location = findViewById(R.id.source_location);
        destination_location = findViewById(R.id.destination_location);
        description_route = findViewById(R.id.description_route);
        url_route = findViewById(R.id.url_route);
        sacco_route = findViewById(R.id.sacco_route);
        fare_route = findViewById(R.id.fare_route);
        rating_route = findViewById(R.id.rating_route);
        source_location_layout = findViewById(R.id.source_location_layout);
        destination_location_layout = findViewById(R.id.destination_location_layout);
        description_route_layout = findViewById(R.id.description_route_layout);
        url_route_layout = findViewById(R.id.url_route_layout);
        rating_route_layout = findViewById(R.id.rating_route_layout);
        sacco_route_layout = findViewById(R.id.sacco_route_layout);
        fare_route_layout = findViewById(R.id.fare_route_layout);

        addRoute = findViewById(R.id.addRoute);
        addRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date d = new Date();

                String source = String.valueOf(source_location.getText());
                String destination = String.valueOf(destination_location.getText());
                String description = String.valueOf(description_route.getText());
                String url = String.valueOf(url_route.getText());
                String sacco = String.valueOf(sacco_route.getText());
                int fare = Integer.parseInt(String.valueOf(fare_route.getText()));
                String time = String.valueOf(d.getTime());
                String dt = String.valueOf(d.getDate()+"/"+d.getMonth());
                int fav = 1;
                int rating = Integer.parseInt(String.valueOf(rating_route.getText()));

                //checks

                if(source.trim().length() <= 0){
                    source_location_layout.setError("Source Name is required");
                }
                if(destination.trim().length() <= 0){
                    destination_location_layout.setError("Destination is required");
                }if(description.trim().length() <= 0){
                    description_route_layout.setError("Description is required");
                }if(url.trim().length() <= 0){
                    url_route_layout.setError("map url is required");
                }if(fare >= 1000){
                    fare_route_layout.setError("Invalid fare amount");
                }if(rating > 5){
                    rating_route_layout.setError("Rate up to 5");
                }
                if(sacco.trim().length() <= 0){
                    sacco_route_layout.setError("Sacco Name is required");
                }

                if(source.trim().length() > 0 && destination.trim().length() > 0 && description.trim().length() > 0 && url.trim().length() > 0  && fare < 1000 && rating <= 5 && sacco.trim().length() > 0 ){
                    progressDialog.show();
                    Route route_item = new Route(source,sacco,destination,description,url,dt,time,fav,rating,fare);
                    myRef = database.getReference("routes").push();
                    myRef.child("source").setValue(source);
                    myRef.child("sacco").setValue(sacco);
                    myRef.child("destination").setValue(destination);
                    myRef.child("description").setValue(description);
                    myRef.child("map_link").setValue(url);
                    myRef.child("date").setValue(dt);
                    myRef.child("time").setValue(time);
                    myRef.child("favorites").setValue(fav);
                    myRef.child("rating").setValue(rating);
                    myRef.child("fare").setValue(fare);

                    progressDialog.hide();
                    Snackbar.make(v,"Route Added",Snackbar.LENGTH_LONG).show();

                    Intent intent = new Intent(getApplicationContext(), SpecificRoute.class);
                    intent.putExtra("Route",new Gson().toJson(route_item));
                    startActivity(intent);
                }
            }
        });

        setTitle("Route Upload");
    }
    private void createDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Authentication");
        progressDialog.setMessage("processing..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMax(100);
        progressDialog.setCancelable(false);
    }
}