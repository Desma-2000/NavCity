package com.desma.navcity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import com.desma.navcity.Adapter.RoutesAdapter;
import com.desma.navcity.Model.Route;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class dashboard extends AppCompatActivity {
RoutesAdapter Adapter;
FloatingActionButton addNewRoutes;
Uri uri = null;
URL url;
ArrayList<Route> routeArrayList = new ArrayList<>();
ArrayList<Route> searchRouteArrayList = new ArrayList<>();

RecyclerView recyclerLocation;
    FirebaseDatabase database;
    DatabaseReference myRef;
    ProgressDialog progressDialog;
    TextInputEditText search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        createDialog();

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("routes");
        recyclerLocation = findViewById(R.id.recyclerLocation);
        addNewRoutes = findViewById(R.id.addNewRoutes);
        search = findViewById(R.id.search);

        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                    String searchQuery = String.valueOf(search.getText());

                    if (searchQuery.trim().length() > 0){
                        //search
                        searchRouteArrayList.clear();
                        for (Route r: routeArrayList ) {
                            if (r.getDestination().toLowerCase().contains(searchQuery.trim().toLowerCase()) || r.getDestination().toLowerCase().matches(searchQuery.trim().toLowerCase())){
                                searchRouteArrayList.add(r);
                            }
                        }
                        if (searchRouteArrayList.size() <= 0){
                            Snackbar.make(v,String.valueOf(search.getText())+" destination not found",Snackbar.LENGTH_LONG).show();
                        }
                        else{
                            setAdapter(searchRouteArrayList);
                        }
                    }


                }
                return false;
            }
        });
        addNewRoutes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),RouteUpload.class);
                startActivity(intent);
            }
        });
        try {
             uri = this.getIntent().getData();
             url = new URL(uri.getScheme(), uri.getHost(), uri.getPath());

        } catch (Exception e) {
            e.printStackTrace();
        }


//        routeArrayList.add(0,new Route("LOCATION ONE","XYZ SACCO","SOMEWHERE"," There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc","https://maps.app.goo.gl/iFtgDszE5YHNaxsC9","02/05/22","6:00pm",10,4,100));
//
//        for (int i = 1; i< 15;i++){
//            routeArrayList.add(i,new Route("LOCATION ONE","XYZ SACCO","SOMEWHERE"," There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc","https://maps.app.goo.gl/5sQPriwWSr6n97kE7","02/05/22","6:00pm",10*i,4,100*i));
//        }
        progressDialog.show();
        myRef.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                routeArrayList.clear();
                for (DataSnapshot snap: snapshot.getChildren() ) {
                    Route item = snap.getValue(Route.class);
                    routeArrayList.add(item);
                }

                setAdapter(routeArrayList);
                Collections.sort(routeArrayList, Comparator.comparing(Route::getRating));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    @SuppressLint("NotifyDataSetChanged")
    private void setAdapter(ArrayList<Route> RouteArrayList) {
        Adapter = new RoutesAdapter(getApplicationContext(),RouteArrayList,this);
        Adapter.notifyDataSetChanged();
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),1);
        recyclerLocation.setLayoutManager(layoutManager);
        recyclerLocation.setHasFixedSize(true);
        recyclerLocation.setAdapter(Adapter);
        progressDialog.hide();

    }
    private void createDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Fetching Routes");
        progressDialog.setMessage("processing..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMax(100);
        progressDialog.setCancelable(false);
    }
}